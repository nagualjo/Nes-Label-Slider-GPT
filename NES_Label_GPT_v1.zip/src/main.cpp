/*
 * NES Label GPT v1 - Donde los sueños se encuentran con los píxeles.
 * Proyecto colaborativo para ESP32 con pantalla TFT, MP3 y RTC.
 */

#include <Arduino.h>

void setup() {
  Serial.begin(115200);
  Serial.println("NES Label GPT - Donde los sueños se encuentran con los píxeles");
  // Aquí inicializaríamos TFT, MP3 y otros módulos
}

void loop() {
  // Comenzar con pantalla de bienvenida
  // Luego mostrar imágenes y reproducir música
}
